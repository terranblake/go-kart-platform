# CrossPlatformCAN Library

A cross-platform CAN interface library that works seamlessly on both Raspberry Pi (Linux) and Arduino platforms. The library provides a consistent API for CAN communication and supports Protocol Buffer message serialization.

## Features

- Unified API for both Raspberry Pi and Arduino platforms
- Automatic platform detection at compile time
- Protocol Buffer message serialization support
- Message handler registration for event-driven programming
- Efficient 8-byte message format supporting various data types

## Requirements

### For Raspberry Pi

- Linux with SocketCAN support (built into Linux kernel)
- CAN hardware interface (e.g., MCP2515 based HAT or USB-CAN adapter)
- C++11 compatible compiler
- CMake 3.10 or newer
- Protocol Buffer generated files

### For Arduino

- Arduino IDE or PlatformIO
- Arduino-CAN library
- CAN transceiver hardware (e.g., MCP2515 + TJA1050)
- SPI connection to the CAN controller

## Installation

### Raspberry Pi

1. Install dependencies:
   ```bash
   sudo apt-get update
   sudo apt-get install -y cmake build-essential can-utils
   ```

2. Set up the directory structure and copy necessary files:
   ```bash
   # Create the directory structure
   mkdir -p ~/go-kart-platform/components/common/lib/CrossPlatformCAN/include
   mkdir -p ~/go-kart-platform/components/common/lib/CrossPlatformCAN/include/nanopb
   mkdir -p ~/go-kart-platform/protocol/generated/nanopb
   
   # Copy the library files
   cp -r * ~/go-kart-platform/components/common/lib/CrossPlatformCAN/
   
   # Copy Protocol Buffer files
   cp protocol/generated/nanopb/common.pb.h ~/go-kart-platform/protocol/generated/nanopb/
   cp protocol/generated/nanopb/common.pb.h ~/go-kart-platform/components/common/lib/CrossPlatformCAN/include/
   
   # Copy nanopb files
   cp protocol/nanopb/pb.h ~/go-kart-platform/components/common/lib/CrossPlatformCAN/include/
   cp protocol/nanopb/pb*.h ~/go-kart-platform/components/common/lib/CrossPlatformCAN/include/nanopb/
   ```

3. Set up your CAN hardware:
   ```bash
   # Configure and bring up the CAN interface
   sudo ip link set can0 type can bitrate 500000
   sudo ip link set up can0
   
   # Verify the interface is up
   ip -details link show can0
   ```

4. Build the library using the provided script:
   ```bash
   cd ~/go-kart-platform/components/common/lib/CrossPlatformCAN
   chmod +x build.sh
   ./build.sh
   ```

5. Run the example:
   ```bash
   cd build
   ./rpi_example
   ```

6. To use the library in your own project, add the following to your CMakeLists.txt:
   ```cmake
   find_package(CrossPlatformCAN REQUIRED)
   target_link_libraries(your_target CrossPlatformCAN)
   ```

### Arduino

1. Install the Arduino-CAN library:
   - Open Arduino IDE
   - Go to Sketch > Include Library > Manage Libraries
   - Search for "CAN" and install the library by Sandeep Mistry

2. Copy the CrossPlatformCAN library files to your Arduino libraries folder:
   ```bash
   cp -r CrossPlatformCAN ~/Arduino/libraries/
   ```

3. Include the library in your sketch:
   ```cpp
   #include <ProtobufCANInterface.h>
   ```

## Usage

### Basic Example

```cpp
#include "ProtobufCANInterface.h"

// Define a node ID for this device
#define NODE_ID 0x01

// Create a CAN interface instance
ProtobufCANInterface canInterface(NODE_ID);

// Handler for received messages
void messageHandler(kart_common_MessageType msg_type, 
                   kart_common_ComponentType comp_type,
                   uint8_t component_id, uint8_t command_id, 
                   kart_common_ValueType value_type, int32_t value) {
  // Handle the message
  // ...
}

void setup() {
  // Initialize CAN interface (default: 500kbps)
  canInterface.begin(500000);
  
  // Register message handler
  canInterface.registerHandler(kart_common_ComponentType_LIGHTS, 
                              0x01, 
                              0x01, 
                              messageHandler);
}

void loop() {
  // Process incoming CAN messages
  canInterface.process();
  
  // Send a message
  canInterface.sendMessage(
    kart_common_MessageType_COMMAND,
    kart_common_ComponentType_LIGHTS,
    0x01,
    0x01,
    kart_common_ValueType_BOOLEAN,
    true
  );
}
```

## Message Format

The library uses a consistent 8-byte message format:

| Byte | Description |
|------|-------------|
| 0    | Header byte: Message type (2 bits) + Component type (6 bits) |
| 1    | Reserved for future use |
| 2    | Component ID |
| 3    | Command ID |
| 4    | Value type (high nibble) + Reserved (low nibble) |
| 5-7  | Value data (up to 24 bits) |

## Troubleshooting

### Raspberry Pi

- Check if the CAN interface is up: `ip -details link show can0`
- Monitor CAN traffic: `candump can0`
- Send a test frame: `cansend can0 123#DEADBEEF`
- If you get compilation errors about missing headers:
  - Ensure all Protocol Buffer headers are in the include directory
  - Make sure nanopb headers are available in include/nanopb
  - Check that common.pb.h correctly includes pb.h

### Arduino

- Verify your SPI connections to the CAN controller
- Check if the CS and INT pins match your configuration
- Use Serial.println to debug message reception and transmission

## Contributing

Contributions to improve the library are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

This library is released under the MIT License. 