#!/usr/bin/env python3
"""
Python example for using the CrossPlatformCAN interface via CFFI.
This example demonstrates:
1. Setting the location of lights
2. Setting the controls diagnostic mode to test

Requirements:
- CFFI: pip install cffi
- can-utils package installed on your system
- CAN interface configured and up

Usage:
python3 can_interface_test.py
"""

import os
import sys
import time
import argparse
from cffi import FFI

# Define message types from Protocol Buffer
MESSAGE_TYPE_COMMAND = 0
MESSAGE_TYPE_STATUS = 1

# Define component types from Protocol Buffer
COMPONENT_TYPE_LIGHTS = 1
COMPONENT_TYPE_CONTROLS = 2

# Define value types from Protocol Buffer
VALUE_TYPE_BOOLEAN = 0
VALUE_TYPE_INT8 = 1
VALUE_TYPE_UINT8 = 2
VALUE_TYPE_INT16 = 3
VALUE_TYPE_UINT16 = 4
VALUE_TYPE_INT24 = 5
VALUE_TYPE_UINT24 = 6

# Define command IDs for lights
LIGHTS_CMD_LOCATION = 3  # Example command for setting light location

# Define command IDs for controls
CONTROLS_CMD_DIAGNOSTIC_MODE = 7  # Example command for setting diagnostic mode

class CANInterface:
    def __init__(self, node_id=0x01, can_device="can0"):
        self.node_id = node_id
        self.can_device = can_device
        self.ffi = FFI()
        
        # Define C function prototypes for CFFI
        self.ffi.cdef("""
            typedef struct ProtobufCANInterface ProtobufCANInterface;
            
            // Constructor/destructor
            ProtobufCANInterface* create_can_interface(uint32_t nodeId);
            void destroy_can_interface(ProtobufCANInterface* instance);
            
            // Member function wrappers
            bool can_interface_begin(ProtobufCANInterface* instance, long baudrate);
            bool can_interface_send_message(ProtobufCANInterface* instance, 
                                          int message_type, int component_type, 
                                          uint8_t component_id, uint8_t command_id, 
                                          int value_type, int32_t value);
            void can_interface_process(ProtobufCANInterface* instance);
            
            // Callback for message reception
            typedef void (*MessageHandlerCallback)(int, int, uint8_t, uint8_t, int, int32_t);
            void can_interface_register_handler(ProtobufCANInterface* instance, 
                                              int component_type, uint8_t component_id, 
                                              uint8_t command_id, 
                                              MessageHandlerCallback handler);
        """)
        
        # For simplicity in this example, we'll use can-utils directly via os.system
        # In a real application, you would compile a Python extension with CFFI
        print(f"Using CAN device: {can_device}")
    
    def send_can_message(self, message_type, component_type, component_id, command_id, value_type, value):
        """Send a message using the cansend utility"""
        # Pack the header byte: message_type (2 bits) | component_type (6 bits)
        header = ((message_type & 0x03) << 6) | (component_type & 0x3F)
        
        # Pack the value type into the high nibble of the 4th byte
        value_type_byte = (value_type & 0x0F) << 4
        
        # Pack the value (up to 24 bits)
        value_byte2 = (value >> 16) & 0xFF  # MSB
        value_byte1 = (value >> 8) & 0xFF   # Middle byte
        value_byte0 = value & 0xFF          # LSB
        
        # Format the CAN message (8 bytes)
        data = f"{header:02X}00{component_id:02X}{command_id:02X}{value_type_byte:02X}{value_byte2:02X}{value_byte1:02X}{value_byte0:02X}"
        
        # Send the message
        cmd = f"cansend {self.can_device} {self.node_id:03X}#{data}"
        print(f"Sending command: {cmd}")
        os.system(cmd)
    
    def set_lights_location(self, location_value):
        """
        Set the location of lights
        
        Args:
            location_value: Integer value representing the location
                0 = FRONT
                1 = REAR
                2 = LEFT
                3 = RIGHT
                4 = CENTER
        """
        print(f"Setting lights location to: {location_value}")
        self.send_can_message(
            message_type=MESSAGE_TYPE_COMMAND,
            component_type=COMPONENT_TYPE_LIGHTS,
            component_id=0x01,  # First lights component
            command_id=LIGHTS_CMD_LOCATION,
            value_type=VALUE_TYPE_UINT8,
            value=location_value
        )
    
    def set_controls_diagnostic_mode(self, enable_test_mode):
        """
        Set the controls diagnostic mode
        
        Args:
            enable_test_mode: Boolean, True to enable test mode, False to disable
        """
        mode_value = 1 if enable_test_mode else 0
        print(f"Setting controls diagnostic mode to: {'TEST' if enable_test_mode else 'NORMAL'}")
        self.send_can_message(
            message_type=MESSAGE_TYPE_COMMAND,
            component_type=COMPONENT_TYPE_CONTROLS,
            component_id=0x01,  # First controls component
            command_id=CONTROLS_CMD_DIAGNOSTIC_MODE,
            value_type=VALUE_TYPE_BOOLEAN,
            value=mode_value
        )
    
    def monitor_can_bus(self, duration=10):
        """Monitor CAN bus for the specified duration (in seconds)"""
        print(f"Monitoring CAN bus for {duration} seconds...")
        os.system(f"timeout {duration} candump {self.can_device}")


def main():
    parser = argparse.ArgumentParser(description='Test the CAN interface')
    parser.add_argument('--device', default='can0', help='CAN device name')
    parser.add_argument('--node-id', type=int, default=0x123, help='CAN node ID')
    args = parser.parse_args()
    
    # Create the CAN interface
    can_interface = CANInterface(node_id=args.node_id, can_device=args.device)
    
    try:
        # Test 1: Set lights location
        print("\n--- Test 1: Setting Lights Location ---")
        locations = {0: "FRONT", 1: "REAR", 2: "LEFT", 3: "RIGHT", 4: "CENTER"}
        
        for loc_value, loc_name in locations.items():
            print(f"\nSetting location to {loc_name}")
            can_interface.set_lights_location(loc_value)
            time.sleep(1)  # Wait for status response
        
        # Test 2: Set controls diagnostic mode
        print("\n--- Test 2: Controls Diagnostic Mode ---")
        print("\nEnabling TEST mode")
        can_interface.set_controls_diagnostic_mode(True)
        time.sleep(1)
        
        print("\nDisabling TEST mode")
        can_interface.set_controls_diagnostic_mode(False)
        time.sleep(1)
        
        # Monitor the CAN bus for a while to see responses
        print("\n--- Monitoring CAN Bus ---")
        can_interface.monitor_can_bus(duration=5)
        
    except KeyboardInterrupt:
        print("\nTest interrupted by user")
    
    print("\nTests completed!")


if __name__ == "__main__":
    main() 