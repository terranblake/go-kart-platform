#!/usr/bin/env python3
"""
Minimal test script for CrossPlatformCAN library
Tests if the shared library can be loaded and basic functions can be called
"""

import os
import sys
from cffi import FFI

def test_library(lib_path=None):
    """Test if the CAN library can be loaded and used"""
    print("Testing CrossPlatformCAN library")
    
    # Get the script directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Create FFI interface
    ffi = FFI()
    
    # Define minimal C API
    ffi.cdef("""
        typedef void* can_interface_t;
        
        // Basic functions to test
        can_interface_t can_interface_create(uint32_t node_id);
        void can_interface_destroy(can_interface_t handle);
    """)
    
    # Try to load the library
    if lib_path is None:
        # Try common locations
        paths = [
            # First try the library in the same directory as this script
            os.path.join(script_dir, "libCrossPlatformCAN.so"),
            # Try relative paths
            os.path.join(script_dir, "../build/libCrossPlatformCAN.so"),
            # Try absolute paths
            os.path.abspath(os.path.join(script_dir, "../build/libCrossPlatformCAN.so")),
        ]
    else:
        paths = [lib_path]
    
    # Try each path
    for path in paths:
        print(f"Trying to load library from: {path}")
        try:
            lib = ffi.dlopen(path)
            print(f"Successfully loaded library from: {path}")
            
            # Get function pointers and check if they exist
            print("Testing function availability:")
            
            create_fn = lib.can_interface_create
            print(f"Found can_interface_create at: {create_fn}")
            
            destroy_fn = lib.can_interface_destroy
            print(f"Found can_interface_destroy at: {destroy_fn}")
            
            # Test creating an interface
            print("Testing function calls:")
            print("Creating CAN interface with node ID: 1")
            handle = lib.can_interface_create(1)
            
            if handle:
                print("SUCCESS: can_interface_create returned valid handle")
                lib.can_interface_destroy(handle)
                print("SUCCESS: can_interface_destroy called without error")
                print("All tests PASSED!")
                return True
            else:
                print("FAILED: can_interface_create returned NULL")
                return False
        except Exception as e:
            print(f"Error: {e}")
            continue
    
    print("FAILED: Could not load the library from any location")
    return False

if __name__ == "__main__":
    # Allow passing a library path as command line argument
    lib_path = sys.argv[1] if len(sys.argv) > 1 else None
    
    if test_library(lib_path):
        print("Library test successful")
        sys.exit(0)
    else:
        print("Library test failed")
        sys.exit(1) 