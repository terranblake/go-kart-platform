#!/usr/bin/env python3
"""
Quick test for CrossPlatformCAN Python interface

This script is similar to test_can_interface.py but runs for a limited time 
and then exits.
"""

import os
import sys
import time
import argparse

# Add the python directory to path if needed
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

from can_interface import CANInterface, MessageType, ComponentType, ValueType

def message_handler(msg_type, comp_type, component_id, command_id, value_type, value):
    """Handler for incoming CAN messages"""
    
    # Get string representations for easier printing
    msg_type_str = "COMMAND" if msg_type == MessageType.COMMAND else "STATUS"
    comp_type_str = "LIGHTS" if comp_type == ComponentType.LIGHTS else "CONTROLS" if comp_type == ComponentType.CONTROLS else str(comp_type)
    value_type_str = "BOOLEAN" if value_type == ValueType.BOOLEAN else "INT" if value_type in (ValueType.INT8, ValueType.INT16, ValueType.INT24) else "UINT"
    
    print(f"┌───────────────────────────────────────────────┐")
    print(f"│ ARDUINO RESPONSE RECEIVED:                    │")
    print(f"│ Message Type: {msg_type_str:<8} ({msg_type})             │")
    print(f"│ Component: {comp_type_str:<10} ({comp_type})             │")
    print(f"│ Component ID: {component_id}                           │")
    print(f"│ Command ID: {command_id}                              │")
    print(f"│ Value Type: {value_type_str:<8} ({value_type})             │")
    print(f"│ Value: {value}                                  │")
    print(f"└───────────────────────────────────────────────┘")

def main():
    """Main test function"""
    parser = argparse.ArgumentParser(description='Test the CrossPlatformCAN Python interface')
    parser.add_argument('--node-id', type=int, default=0x01, help='CAN node ID')
    parser.add_argument('--device', default='can0', help='CAN device name')
    parser.add_argument('--lib-path', default='./python/libCrossPlatformCAN.so', help='Path to the CrossPlatformCAN library')
    parser.add_argument('--runtime', type=int, default=5, help='Runtime in seconds')
    args = parser.parse_args()
    
    try:
        # Create CAN interface
        print(f"Creating CAN interface with node ID 0x{args.node_id:X} on device {args.device}")
        can = CANInterface(args.node_id, args.lib_path)
        
        # Initialize CAN interface
        if not can.begin(500000, args.device):
            print("Failed to initialize CAN interface")
            return 1
        print("CAN interface initialized successfully")
        
        # Register message handlers for all possible message types to catch any responses
        print("Registering message handlers for all relevant message types...")
        
        # Register a general handler for ANY component/command
        can.register_handler(
            ComponentType.LIGHTS,  # Type
            0xFF,                 # ANY component ID (wildcard)
            0xFF,                 # ANY command ID (wildcard)
            message_handler
        )
        
        can.register_handler(
            ComponentType.CONTROLS,  # Type
            0xFF,                   # ANY component ID (wildcard)
            0xFF,                   # ANY command ID (wildcard)
            message_handler
        )
        
        # Start automatic message processing
        print("Starting message processing...")
        can.start_processing()
        
        # Test 1: Set lights location
        print("\n--- Test 1: Setting Lights Location ---")
        print("\nSending command: SET LIGHTS LOCATION = FRONT (0)")
        success = can.set_lights_location(0)  # FRONT location
        print(f"Send {'succeeded' if success else 'failed'}")
        time.sleep(0.5)
        
        # Test 2: Set controls diagnostic mode
        print("\n--- Test 2: Controls Diagnostic Mode ---")
        print("\nSending command: SET DIAGNOSTIC MODE = ENABLED")
        success = can.set_controls_diagnostic_mode(True)  # Enable diagnostic mode
        print(f"Send {'succeeded' if success else 'failed'}")
        time.sleep(0.5)
        
        # Run for specified time then exit
        print(f"\nWaiting {args.runtime} seconds for any additional responses...")
        end_time = time.time() + args.runtime
        while time.time() < end_time:
            time.sleep(0.1)
            
    except KeyboardInterrupt:
        print("\nTest interrupted by user")
    except Exception as e:
        print(f"Error: {e}")
        return 1
    finally:
        if 'can' in locals():
            print("Stopping message processing...")
            can.stop_processing()
    
    print("Test completed")
    return 0

if __name__ == "__main__":
    sys.exit(main()) 