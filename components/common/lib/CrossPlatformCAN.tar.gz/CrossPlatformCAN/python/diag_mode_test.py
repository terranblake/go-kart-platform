#!/usr/bin/env python3
"""
Diagnostic mode test script that uses the exact values from the protocol files:
- COMMAND (0), CONTROLS (4), DIAGNOSTIC (8), MODE (3), TEST (6)
"""

import os
import sys
import time
import argparse

# Add the python directory to path if needed
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

from can_interface import CANInterface

# Direct values from the protocol files
COMMAND = 0
CONTROLS = 4
DIAGNOSTIC = 8
MODE = 3
TEST = 6

def main():
    """Main test function"""
    parser = argparse.ArgumentParser(description='Test diagnostic mode with exact protocol values')
    parser.add_argument('--node-id', type=int, default=0x01, help='CAN node ID')
    parser.add_argument('--device', default='can0', help='CAN device name')
    parser.add_argument('--lib-path', default='./python/libCrossPlatformCAN.so', help='Path to the CrossPlatformCAN library')
    args = parser.parse_args()
    
    try:
        # Create CAN interface
        print(f"Creating CAN interface with node ID 0x{args.node_id:X}")
        can = CANInterface(args.node_id, args.lib_path)
        
        # Initialize CAN interface without resetting
        print(f"Initializing CAN interface (device {args.device})")
        if not can.begin(500000, args.device):
            print("Failed to initialize CAN interface")
            return 1
        print("CAN interface initialized successfully")
        
        # Send diagnostic test mode command with explicit values from protocol
        print("\n--- Sending Diagnostic TEST Mode command ---")
        print(f"Message Type: COMMAND ({COMMAND})")
        print(f"Component Type: CONTROLS ({CONTROLS})")
        print(f"Component ID: DIAGNOSTIC ({DIAGNOSTIC})")
        print(f"Command ID: MODE ({MODE})")
        print(f"Value Type: UINT8 (2)")
        print(f"Value: TEST ({TEST})")
        
        success = can.send_message(
            COMMAND,       # MessageType.COMMAND
            CONTROLS,      # ComponentType.CONTROLS
            DIAGNOSTIC,    # Component ID
            MODE,          # Command ID
            2,             # ValueType.UINT8
            TEST           # Value
        )
        print(f"Send {'succeeded' if success else 'failed'}")
        
        print("\nCommand sent successfully")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        return 1
        
    return 0

if __name__ == "__main__":
    sys.exit(main()) 