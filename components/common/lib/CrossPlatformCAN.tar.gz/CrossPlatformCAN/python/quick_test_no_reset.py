#!/usr/bin/env python3
"""
Minimal test script for CrossPlatformCAN without resetting the CAN interface

This script performs two basic operations:
1. Sets the light location to FRONT (0)
2. Enables diagnostic mode
"""

import os
import sys
import time
import argparse

# Add the python directory to path if needed
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

from can_interface import CANInterface, MessageType, ComponentType, ValueType

def main():
    """Main test function"""
    parser = argparse.ArgumentParser(description='Test the CrossPlatformCAN Python interface')
    parser.add_argument('--node-id', type=int, default=0x01, help='CAN node ID')
    parser.add_argument('--device', default='can0', help='CAN device name')
    parser.add_argument('--lib-path', default='./python/libCrossPlatformCAN.so', help='Path to the CrossPlatformCAN library')
    args = parser.parse_args()
    
    try:
        # Create CAN interface
        print(f"Creating CAN interface with node ID 0x{args.node_id:X} on device {args.device}")
        can = CANInterface(args.node_id, args.lib_path)
        
        # Initialize CAN interface without resetting
        print(f"Initializing CAN interface (device {args.device} should already be up)")
        if not can.begin(500000, args.device):
            print("Failed to initialize CAN interface")
            return 1
        print("CAN interface initialized successfully")
        
        # Test 1: Set lights location to FRONT
        print("\n--- Setting Lights Location to FRONT ---")
        success = can.set_lights_location(0)  # FRONT location
        print(f"Send {'succeeded' if success else 'failed'}")
        time.sleep(0.1)
        
        # Test 2: Enable diagnostic mode
        print("\n--- Enabling Diagnostic Mode ---")
        success = can.set_controls_diagnostic_mode(True)  # Enable diagnostic mode
        print(f"Send {'succeeded' if success else 'failed'}")
        time.sleep(0.1)
        
        print("\nOperations completed successfully")
        
    except Exception as e:
        print(f"Error: {e}")
        return 1
    finally:
        if 'can' in locals():
            can.stop_processing()
    
    return 0

if __name__ == "__main__":
    sys.exit(main()) 