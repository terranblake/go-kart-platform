#!/usr/bin/env python3
"""
Direct CFFI test for CrossPlatformCAN library

This script uses CFFI directly to test the C API functions without any wrappers.
It's meant to provide clear visibility into what's happening with the library.
"""

import os
import sys
import time
from cffi import FFI

def main():
    print("Starting direct CFFI test for CrossPlatformCAN")
    
    # Initialize CFFI
    ffi = FFI()
    
    # Define the C API
    ffi.cdef("""
        typedef void* can_interface_t;
        
        // Constructor/destructor
        can_interface_t can_interface_create(uint32_t node_id);
        void can_interface_destroy(can_interface_t handle);
        
        // Member function wrappers
        bool can_interface_begin(can_interface_t handle, long baudrate, const char* device);
        
        // Message sending
        bool can_interface_send_message(
            can_interface_t handle,
            int msg_type,
            int comp_type,
            uint8_t component_id,
            uint8_t command_id,
            int value_type,
            int32_t value
        );
    """)
    
    # Find and load library
    lib_path = "./python/libCrossPlatformCAN.so"
    abs_path = os.path.abspath(lib_path)
    
    print(f"Attempting to load library from: {lib_path}")
    print(f"Absolute path: {abs_path}")
    
    if not os.path.exists(abs_path):
        print(f"ERROR: Library file does not exist at {abs_path}")
        return 1
        
    try:
        # Check if library is valid
        print(f"Checking library file:")
        os.system(f"file {abs_path}")
        os.system(f"ldd {abs_path}")
        print(f"Exported symbols:")
        os.system(f"nm -D {abs_path} | grep can_interface")
        
        # Load the library
        print("Loading library...")
        lib = ffi.dlopen(abs_path)
        print("Library loaded successfully")
        
        # Create a CAN interface
        print("Creating CAN interface with node ID 0x01...")
        handle = lib.can_interface_create(0x01)
        if handle == ffi.NULL:
            print("ERROR: Failed to create CAN interface, handle is NULL")
            return 1
        print(f"CAN interface created, handle: {handle}")
        
        # Initialize the interface
        print("Initializing CAN interface on can0...")
        device = ffi.new("char[]", b"can0")
        result = lib.can_interface_begin(handle, 500000, device)
        if not result:
            print("ERROR: Failed to initialize CAN interface")
            lib.can_interface_destroy(handle)
            return 1
        print("CAN interface initialized successfully")
        
        # Send a test message
        print("\nSending test message...")
        msg_type = 0  # COMMAND
        comp_type = 1  # LIGHTS
        comp_id = 1
        cmd_id = 3    # Location
        value_type = 2  # UINT8
        value = 2     # LEFT
        
        result = lib.can_interface_send_message(
            handle,
            msg_type,
            comp_type,
            comp_id,
            cmd_id,
            value_type,
            value
        )
        print(f"Message send {'succeeded' if result else 'failed'}")
        
        # Clean up
        print("\nCleaning up...")
        lib.can_interface_destroy(handle)
        print("CAN interface destroyed")
        
    except Exception as e:
        print(f"ERROR: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        return 1
        
    print("Test completed successfully")
    return 0

if __name__ == "__main__":
    sys.exit(main()) 