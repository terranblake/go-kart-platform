#!/usr/bin/env python3
"""
Script to send CAN messages directly using can-utils (cansend)
This bypasses our library entirely to test the hardware setup
"""

import os
import sys
import time
import subprocess
import threading
import queue

# Queue for capturing candump output
candump_queue = queue.Queue()

def candump_monitor(device, duration=30):
    """Run candump in a separate thread and capture output"""
    print(f"Starting CAN bus monitoring on {device} for {duration} seconds...")
    
    try:
        # Use candump with timestamps
        cmd = ["candump", device, "-t", "a"]
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1
        )
        
        # Read output line by line
        start_time = time.time()
        while time.time() - start_time < duration:
            line = process.stdout.readline().strip()
            if line:
                print(f"CAN: {line}")
                candump_queue.put(line)
            
            # Check if process has terminated
            if process.poll() is not None:
                break
                
        # Terminate process if it's still running
        if process.poll() is None:
            process.terminate()
            process.wait(timeout=2)
            
    except Exception as e:
        print(f"Error in candump monitor: {e}")
    finally:
        print("CAN bus monitoring stopped")

def send_can_message(device, can_id, data):
    """Send a CAN message using cansend utility"""
    cmd = ["cansend", device, f"{can_id:03X}#{data}"]
    print(f"Executing: {' '.join(cmd)}")
    try:
        result = subprocess.run(cmd, 
                            check=True, 
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,
                            text=True)
        print("Command executed successfully")
        
        # Check if there was any error in stderr
        if result.stderr:
            print(f"Command stderr: {result.stderr}")
            return False
            
        # Check if CAN message appears in the candump output
        time.sleep(0.5)  # Give a moment for candump to capture
        
        # Look for the message in the queue
        try:
            while not candump_queue.empty():
                line = candump_queue.get_nowait()
                if f"{can_id:03X}" in line and data.lower() in line.lower():
                    print(f"Confirmed message appears in CAN traffic: {line}")
                    return True
        except queue.Empty:
            pass
            
        print("WARNING: Message not found in CAN traffic!")
        return False
    except subprocess.CalledProcessError as e:
        print(f"Error sending message: {e}")
        if e.stderr:
            print(f"Error details: {e.stderr}")
        return False

def pack_lights_location_command(location=0):
    """
    Pack a message to set lights location to FRONT
    
    Byte 0: Header (message_type << 6 | component_type)
    Byte 1: Reserved (0)
    Byte 2: Component ID
    Byte 3: Command ID
    Byte 4: Value type
    Byte 5-7: Value (3 bytes)
    """
    # Constants from protocol buffer definitions
    MESSAGE_TYPE_COMMAND = 0  # 2 bits
    COMPONENT_TYPE_LIGHTS = 1  # 6 bits
    COMPONENT_ID_FRONT = 0
    COMMAND_ID_LOCATION = 9
    VALUE_TYPE_UINT8 = 2  # In high nibble
    
    # Pack header byte
    header = (MESSAGE_TYPE_COMMAND << 6) | (COMPONENT_TYPE_LIGHTS & 0x3F)
    
    # Pack value type into high nibble of byte 4
    value_type_byte = (VALUE_TYPE_UINT8 << 4)
    
    # Pack value (24 bits, little endian)
    value_byte2 = (location >> 16) & 0xFF  # Most significant byte
    value_byte1 = (location >> 8) & 0xFF   # Middle byte
    value_byte0 = location & 0xFF          # Least significant byte
    
    # Format the data string for cansend
    data = f"{header:02X}00{COMPONENT_ID_FRONT:02X}{COMMAND_ID_LOCATION:02X}{value_type_byte:02X}{value_byte2:02X}{value_byte1:02X}{value_byte0:02X}"
    
    return data

def pack_controls_diagnostic_command(mode=6):
    """
    Pack a message to set controls diagnostic mode to TEST
    
    Byte 0: Header (message_type << 6 | component_type)
    Byte 1: Reserved (0)
    Byte 2: Component ID
    Byte 3: Command ID
    Byte 4: Value type
    Byte 5-7: Value (3 bytes)
    """
    # Constants from protocol buffer definitions
    MESSAGE_TYPE_COMMAND = 0  # 2 bits
    COMPONENT_TYPE_CONTROLS = 2  # 6 bits
    COMPONENT_ID_DIAGNOSTIC = 8
    COMMAND_ID_MODE = 3
    VALUE_TYPE_UINT8 = 2  # In high nibble
    
    # Pack header byte
    header = (MESSAGE_TYPE_COMMAND << 6) | (COMPONENT_TYPE_CONTROLS & 0x3F)
    
    # Pack value type into high nibble of byte 4
    value_type_byte = (VALUE_TYPE_UINT8 << 4)
    
    # Pack value (24 bits, little endian)
    value_byte2 = (mode >> 16) & 0xFF  # Most significant byte
    value_byte1 = (mode >> 8) & 0xFF   # Middle byte
    value_byte0 = mode & 0xFF          # Least significant byte
    
    # Format the data string for cansend
    data = f"{header:02X}00{COMPONENT_ID_DIAGNOSTIC:02X}{COMMAND_ID_MODE:02X}{value_type_byte:02X}{value_byte2:02X}{value_byte1:02X}{value_byte0:02X}"
    
    return data

def check_can_interface(device):
    """Check if the CAN interface is up and in a good state"""
    try:
        # Check interface status using ip link
        result = subprocess.run(
            ["ip", "-details", "link", "show", device],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True
        )
        
        output = result.stdout
        print("\nCAN Interface Status:")
        print(output)
        
        # Check for ERROR states
        if "ERROR-PASSIVE" in output:
            print("WARNING: Interface is in ERROR-PASSIVE state")
            return False
        elif "ERROR-ACTIVE" in output:
            print("Interface is in ERROR-ACTIVE state")
            return True
        elif "ERROR" in output:
            print("WARNING: Interface is in an ERROR state")
            return False
        
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error checking CAN interface: {e}")
        return False

def main():
    # CAN device to use
    can_device = "can0"
    
    # Node ID to use (same as in the Python scripts)
    node_id = 0x01
    
    print(f"\n--- Testing direct CAN message sending with can-utils ---")
    print(f"Using CAN device: {can_device}")
    print(f"Using node ID: {node_id:03X}")
    
    # First check the CAN interface
    if not check_can_interface(can_device):
        print("\nTrying to reset the CAN interface...")
        try:
            subprocess.run(["sudo", "ip", "link", "set", can_device, "down"], check=True)
            time.sleep(0.5)
            subprocess.run(["sudo", "ip", "link", "set", can_device, "up", "type", "can", "bitrate", "500000"], check=True)
            time.sleep(0.5)
            if check_can_interface(can_device):
                print("Successfully reset CAN interface")
            else:
                print("WARNING: CAN interface still has issues after reset")
        except Exception as e:
            print(f"Error resetting CAN interface: {e}")
    
    # Start monitoring thread
    monitor_thread = threading.Thread(target=candump_monitor, args=(can_device, 20))
    monitor_thread.daemon = True
    monitor_thread.start()
    
    # Give monitor time to start
    time.sleep(2)
    
    # 1. Send lights location command
    print("\n--- Sending Lights Location Command ---")
    data = pack_lights_location_command(location=0)  # 0 = FRONT
    print(f"Command data: {data}")
    send_can_message(can_device, node_id, data)
    
    # Wait a moment
    time.sleep(1)
    
    # 2. Send controls diagnostic mode command
    print("\n--- Sending Controls Diagnostic Mode Command ---")
    data = pack_controls_diagnostic_command(mode=6)  # 6 = TEST
    print(f"Command data: {data}")
    send_can_message(can_device, node_id, data)
    
    print("\n--- Commands Completed ---")
    print("Monitoring for 5 more seconds to detect any responses...")
    time.sleep(5)
    
    # Give thread time to complete
    if monitor_thread.is_alive():
        print("Waiting for monitoring to complete...")
        monitor_thread.join(timeout=5)
    
    # Display final summary
    print("\n--- Test Summary ---")
    if candump_queue.empty():
        print("No CAN messages were observed on the bus.")
        print("This suggests there might be issues with the CAN hardware or driver.")
    else:
        print(f"Observed {candump_queue.qsize()} CAN messages on the bus.")
        print("The messages were sent, but the Arduino may not be receiving them")
        print("or may be configured to ignore them.")
    
    print("\nPossible issues to check:")
    print("1. Verify the Arduino is powered on and connected to the CAN bus")
    print("2. Check physical connections (CAN_H, CAN_L, GND)")
    print("3. Verify the Arduino CAN node ID matches what we're sending to")
    print("4. Check if the Arduino is using the correct bitrate (500kbps)")
    print("5. Verify the Protocol Buffer message format matches on both sides")

if __name__ == "__main__":
    main() 