#!/usr/bin/env python3
"""
Simplified test script for CrossPlatformCAN Python interface

This script does minimal operations to test just the core functionality.
"""

import os
import sys
import time
import socket
import struct
from can_interface import CANInterface, MessageType, ComponentType, ValueType

def main():
    """Simple test function"""
    device = 'can0'
        
    print("\n--- Next testing Python CANInterface with C library ---")
    try:
        # Create CAN interface
        print("Creating CAN interface with node ID 0x01")
        can = CANInterface(0x01)
        
        # Initialize CAN interface
        print(f"Initializing CAN interface on device {device}")
        if not can.begin(500000, device):
            print("Failed to initialize CAN interface")
            return 1
        print("CAN interface initialized successfully")
        
        # Test a single message send
        print("\nSending a test message")
        success = can.send_message(
            MessageType.COMMAND,
            ComponentType.LIGHTS,
            0x01,  # Component ID
            0x03,  # Command ID for location
            ValueType.UINT8,
            0x02   # Location value (LEFT)
        )
        print(f"Message send {'succeeded' if success else 'failed'}")

        success = can.send_message(
            MessageType.COMMAND,
            ComponentType.CONTROLS,
            0x01,  # Component ID
            0x03,  # Command ID for location
            ValueType.UINT8,
            0x02   # Location value (LEFT)
        )
        print(f"Message send {'succeeded' if success else 'failed'}")
        
        # Wait a moment before exit
        time.sleep(1)
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    print("Test completed successfully")
    return 0

if __name__ == "__main__":
    sys.exit(main()) 