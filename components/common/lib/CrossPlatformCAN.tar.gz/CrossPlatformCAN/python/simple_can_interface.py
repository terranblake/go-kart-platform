#!/usr/bin/env python3
"""
Minimal Python interface for CrossPlatformCAN library
"""

import os
import sys
from cffi import FFI

class SimpleCANInterface:
    """Minimal wrapper for the CrossPlatformCAN library"""
    
    def __init__(self, node_id=0x01, lib_path=None):
        """Initialize the CAN interface"""
        print(f"Initializing CAN interface with node ID: {node_id}")
        
        # Initialize CFFI
        self.ffi = FFI()
        
        # Define the C API
        self.ffi.cdef("""
            typedef void* can_interface_t;
            
            // Constructor/destructor
            can_interface_t can_interface_create(uint32_t node_id);
            void can_interface_destroy(can_interface_t handle);
            
            // Member function wrappers
            bool can_interface_begin(can_interface_t handle, long baudrate, const char* device);
            bool can_interface_send_message(
                can_interface_t handle,
                int msg_type,
                int comp_type,
                uint8_t component_id,
                uint8_t command_id,
                int value_type,
                int32_t value
            );
        """)
        
        # Load the library
        self.lib = self._load_library(lib_path)
        
        # Create the interface
        self.handle = self.lib.can_interface_create(node_id)
        if not self.handle:
            raise RuntimeError("Failed to create CAN interface")
            
        print("CAN interface created successfully")
    
    def _load_library(self, lib_path):
        """Load the library from the specified path or search for it"""
        # Get the script directory
        script_dir = os.path.dirname(os.path.abspath(__file__))
        
        paths = []
        if lib_path:
            paths.append(lib_path)
        
        # Add common paths
        paths.extend([
            # First try the library in the same directory as this script
            os.path.join(script_dir, "libCrossPlatformCAN.so"),
            # Try relative paths
            os.path.join(script_dir, "../build/libCrossPlatformCAN.so"),
            # Try absolute paths
            os.path.abspath(os.path.join(script_dir, "../build/libCrossPlatformCAN.so")),
            # Standard system locations
            "/usr/local/lib/libCrossPlatformCAN.so",
            "/usr/lib/libCrossPlatformCAN.so"
        ])
        
        # Try each path
        for path in paths:
            print(f"Trying to load library from: {path}")
            try:
                lib = self.ffi.dlopen(path)
                print(f"Successfully loaded library from: {path}")
                return lib
            except Exception as e:
                print(f"Failed to load from {path}: {e}")
        
        raise ImportError("Could not find CrossPlatformCAN library")
    
    def __del__(self):
        """Clean up resources"""
        if hasattr(self, 'handle') and self.handle:
            print("Destroying CAN interface")
            self.lib.can_interface_destroy(self.handle)
    
    def begin(self, baudrate=500000, device="can0"):
        """Initialize the CAN interface hardware"""
        print(f"Beginning CAN communication: baudrate={baudrate}, device={device}")
        device_str = self.ffi.new("char[]", device.encode('utf-8'))
        result = self.lib.can_interface_begin(self.handle, baudrate, device_str)
        print(f"CAN initialization {'succeeded' if result else 'failed'}")
        return result
    
    def send_message(self, msg_type, comp_type, comp_id, cmd_id, val_type, value):
        """Send a message on the CAN bus"""
        print(f"Sending message: type={msg_type}, comp_type={comp_type}, comp_id={comp_id}, cmd_id={cmd_id}, val_type={val_type}, value={value}")
        result = self.lib.can_interface_send_message(
            self.handle,
            msg_type,
            comp_type,
            comp_id,
            cmd_id,
            val_type,
            value
        )
        print(f"Message send {'succeeded' if result else 'failed'}")
        return result

# Example usage
if __name__ == "__main__":
    try:
        # Create interface
        can = SimpleCANInterface()
        
        # Initialize CAN hardware
        if can.begin():
            print("Successfully initialized CAN hardware")
            
            # Send a test message
            MSG_TYPE_COMMAND = 0
            COMP_TYPE_LIGHTS = 1
            
            success = can.send_message(
                MSG_TYPE_COMMAND,  # Message type (COMMAND)
                COMP_TYPE_LIGHTS,  # Component type (LIGHTS)
                0x01,              # Component ID
                0x03,              # Command ID (location)
                0x02,              # Value type (UINT8)
                0x00               # Value (FRONT)
            )
            
            print(f"Test message sent: {'success' if success else 'failure'}")
        else:
            print("Failed to initialize CAN hardware")
    except Exception as e:
        print(f"Error: {e}") 