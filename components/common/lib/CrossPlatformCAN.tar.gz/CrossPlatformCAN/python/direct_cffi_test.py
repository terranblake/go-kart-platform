#!/usr/bin/env python3
"""
Direct test of CFFI interface for CrossPlatformCAN
"""

import os
import sys
import time
from can_interface import CANInterface, MessageType, ComponentType, ValueType

def main():
    # Get the absolute path of the shared library
    lib_path = os.path.abspath("./libCrossPlatformCAN.so")
    print(f"Using library at: {lib_path}")
    
    # Check if the library exists
    if not os.path.exists(lib_path):
        print(f"ERROR: Library not found at {lib_path}")
        print("Trying alternative locations...")
        
        alt_paths = [
            "../build/libCrossPlatformCAN.so",
            "../python/libCrossPlatformCAN.so"
        ]
        
        for alt_path in alt_paths:
            alt_path = os.path.abspath(alt_path)
            print(f"Checking: {alt_path}")
            if os.path.exists(alt_path):
                lib_path = alt_path
                print(f"Found library at: {lib_path}")
                break
        else:
            print("No library found!")
            return 1
        
    # Verify the library is a shared library
    print(f"Library details:")
    os.system(f"file {lib_path}")
    print(f"Library symbols:")
    os.system(f"nm -D {lib_path} | grep can_interface")
    
    # Initialize the CAN interface
    try:
        print("\nInitializing CAN interface...")
        can = CANInterface(node_id=0x01, lib_path=lib_path)
        print("CANInterface created successfully")
        
        # Initialize CAN device
        print("\nStarting CAN interface...")
        if not can.begin(500000, "can0"):
            print("ERROR: Failed to initialize CAN interface")
            return 1
        print("CAN interface initialized successfully")
        
        # Send a test message
        print("\nSending test message...")
        success = can.send_message(
            MessageType.COMMAND,
            ComponentType.LIGHTS,
            0x01,  # Component ID
            0x03,  # Command ID for location
            ValueType.UINT8,
            0x02   # LEFT location
        )
        print(f"Message send {'succeeded' if success else 'failed'}")
        
        # Wait a moment
        time.sleep(0.5)
        
        # Using convenience method
        print("\nSending another message using convenience method...")
        success = can.set_lights_location(0x03)  # RIGHT location
        print(f"Message send {'succeeded' if success else 'failed'}")
        
    except Exception as e:
        print(f"ERROR: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        return 1
        
    print("\nTest completed successfully")
    return 0

if __name__ == "__main__":
    sys.exit(main()) 