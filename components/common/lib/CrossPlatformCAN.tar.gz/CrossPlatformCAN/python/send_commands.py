#!/usr/bin/env python3
"""
Script to send specific CAN commands:
1. Set the lights location to FRONT
2. Set the controls mode to TEST

Both commands are sent to node ID 1.
"""

import os
import sys
import time
from simple_can_interface import SimpleCANInterface

# MessageType constants from common.pb.h
class MessageType:
    COMMAND = 0
    STATUS = 1

# ComponentType constants from common.pb.h
class ComponentType:
    LIGHTS = 1
    CONTROLS = 2

# ValueType constants from common.pb.h
class ValueType:
    BOOLEAN = 0
    UINT8 = 2  # Unsigned 8-bit integer

# Light component IDs from lights.pb.h
class LightComponentId:
    FRONT = 0
    REAR = 1
    INTERIOR = 4
    AUXILIARY = 8
    UNDERGLOW = 9

# Light command IDs from lights.pb.h
class LightCommandId:
    MODE = 0
    SIGNAL = 1
    INTENSITY = 2
    PATTERN = 3
    COLOR = 4
    DURATION = 5
    TOGGLE = 6
    SEQUENCE = 7
    BRAKE = 8
    LOCATION = 9  # Command to set the location

# Light location values
class LightLocationValue:
    FRONT = 0
    REAR = 1
    LEFT = 2
    RIGHT = 3
    CENTER = 4

# Control component IDs from controls.pb.h
class ControlComponentId:
    THROTTLE = 0
    BRAKE = 1
    STEERING = 2
    DIAGNOSTIC = 8

# Control command IDs from controls.pb.h
class ControlCommandId:
    ENABLE = 0
    DISABLE = 1
    RESET = 2
    MODE = 3
    PARAMETER = 4
    LIMIT = 5
    CALIBRATE = 6
    EMERGENCY = 7

# Control mode values from controls.pb.h
class ControlModeValue:
    MANUAL = 0
    ASSISTED = 1
    AUTOMATIC = 2
    SPORT = 3
    ECO = 4
    SAFETY = 5
    TEST = 6  # Test mode for diagnostic purposes

def main():
    try:
        # Create a CAN interface with node ID 1
        print("\n--- Initializing CAN Interface ---")
        can = SimpleCANInterface(node_id=0x01)
        
        # Initialize CAN hardware
        if can.begin(baudrate=500000, device="can0"):
            print("\n--- CAN Interface Initialized ---")
            
            # 1. Send command to set lights location to FRONT
            print("\n--- Sending Lights Location Command ---")
            print(f"Setting lights location to FRONT (location value: {LightLocationValue.FRONT})")
            
            success = can.send_message(
                MessageType.COMMAND,          # Message type: COMMAND
                ComponentType.LIGHTS,         # Component type: LIGHTS
                LightComponentId.FRONT,       # Component ID: FRONT
                LightCommandId.LOCATION,      # Command ID: LOCATION
                ValueType.UINT8,              # Value type: UINT8
                LightLocationValue.FRONT      # Value: FRONT
            )
            
            print(f"Lights location command sent: {'SUCCESS' if success else 'FAILED'}")
            
            # Wait a moment between commands
            time.sleep(1)
            
            # 2. Send command to set controls diagnostic mode to TEST
            print("\n--- Sending Controls Mode Command ---")
            print(f"Setting controls diagnostic mode to TEST (mode value: {ControlModeValue.TEST})")
            
            success = can.send_message(
                MessageType.COMMAND,          # Message type: COMMAND
                ComponentType.CONTROLS,       # Component type: CONTROLS
                ControlComponentId.DIAGNOSTIC, # Component ID: DIAGNOSTIC
                ControlCommandId.MODE,        # Command ID: MODE
                ValueType.UINT8,              # Value type: UINT8
                ControlModeValue.TEST         # Value: TEST
            )
            
            print(f"Controls diagnostic mode command sent: {'SUCCESS' if success else 'FAILED'}")
            
            # Final status
            print("\n--- Commands Completed ---")
            
        else:
            print("Failed to initialize CAN hardware")
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main() 